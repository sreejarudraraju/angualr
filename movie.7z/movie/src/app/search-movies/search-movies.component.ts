import { Component, OnInit } from '@angular/core';
import { TouchSequence } from 'selenium-webdriver';
import { MsService } from '../ms.service';
import{Movie}from '../Movie' 
import { Observable } from 'rxjs';
@Component({
  selector: 'app-search-movies',
  templateUrl: './search-movies.component.html',
  styleUrls: ['./search-movies.component.css']
})
export class SearchMoviesComponent implements OnInit {
  movieList: any = [];
  movie: Movie = new Movie();
  constructor(private movieservice:MsService) {
    this.movieservice.getmovieDetails().subscribe(data => this.movieList = data);
   }
  ngOnInit() {
  }
  s:any[]
  genre: string[] = ["DRA", "FI", "SCIFI","LOVE"];
  searchmovie(data)
  {
    
   this.s=this.movieservice.search(data);
  }

}
