export interface Game {
    gameId:number;
    gameName:string;
    gamePrice:number;
}

